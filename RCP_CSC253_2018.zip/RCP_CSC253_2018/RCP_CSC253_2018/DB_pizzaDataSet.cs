﻿namespace RCP_CSC253_2018
{
    public partial class DB_pizzaDataSet
    {
        partial class OrdersDataTable
        {
        }
    }
}

namespace RCP_CSC253_2018.DB_pizzaDataSetTableAdapters
{
    partial class OrdersTableAdapter
    {
    }

    partial class ToppingsTableAdapter
    {
    }

    public partial class CustomersTableAdapter {
    }
}
